﻿---@class foostruct
---@field public x Single
---@field public y Single
---@field public z Single
---@field public w Single
---@field public mode Int32
local foostruct={ }
.foostruct = foostruct