﻿---@class SLuaTest
---@field public intevent FloatEvent
local SLuaTest={ }
.SLuaTest = SLuaTest