﻿---@class AbsClass
---@field public x Int32
local AbsClass={ }
.AbsClass = AbsClass