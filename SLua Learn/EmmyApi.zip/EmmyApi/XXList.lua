﻿---@class XXList
local XXList={ }
.XXList = XXList