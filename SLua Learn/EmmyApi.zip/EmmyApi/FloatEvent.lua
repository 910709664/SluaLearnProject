﻿---@class FloatEvent
local FloatEvent={ }
.FloatEvent = FloatEvent