﻿---@class NewCoroutine
local NewCoroutine={ }
---@public
---@param test string
---@param time Single
---@param func LuaFunction
---@return IEnumerator
function NewCoroutine.MyMethod(test, time, func) end
.NewCoroutine = NewCoroutine